﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblHead = New Label()
        lblFood = New Label()
        lblDrink = New Label()
        txtFood = New TextBox()
        txtDrink = New TextBox()
        btnCalc = New Button()
        lblTotal = New Label()
        lblTax = New Label()
        lblFinal = New Label()
        txtTotal = New TextBox()
        txtTax = New TextBox()
        txtFinal = New TextBox()
        SuspendLayout()
        ' 
        ' lblHead
        ' 
        lblHead.AutoSize = True
        lblHead.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        lblHead.Location = New Point(108, 37)
        lblHead.Name = "lblHead"
        lblHead.Size = New Size(107, 17)
        lblHead.TabIndex = 0
        lblHead.Text = "Enter bill totals:"
        ' 
        ' lblFood
        ' 
        lblFood.AutoSize = True
        lblFood.Location = New Point(49, 86)
        lblFood.Name = "lblFood"
        lblFood.Size = New Size(56, 15)
        lblFood.TabIndex = 1
        lblFood.Text = "Food Bill:"
        ' 
        ' lblDrink
        ' 
        lblDrink.AutoSize = True
        lblDrink.Location = New Point(49, 122)
        lblDrink.Name = "lblDrink"
        lblDrink.Size = New Size(57, 15)
        lblDrink.TabIndex = 2
        lblDrink.Text = "Drink Bill:"
        ' 
        ' txtFood
        ' 
        txtFood.Location = New Point(156, 78)
        txtFood.Name = "txtFood"
        txtFood.Size = New Size(100, 23)
        txtFood.TabIndex = 3
        ' 
        ' txtDrink
        ' 
        txtDrink.Location = New Point(156, 114)
        txtDrink.Name = "txtDrink"
        txtDrink.Size = New Size(100, 23)
        txtDrink.TabIndex = 4
        ' 
        ' btnCalc
        ' 
        btnCalc.Location = New Point(108, 168)
        btnCalc.Name = "btnCalc"
        btnCalc.Size = New Size(107, 35)
        btnCalc.TabIndex = 5
        btnCalc.Text = "Calculate"
        btnCalc.UseVisualStyleBackColor = True
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(49, 237)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(54, 15)
        lblTotal.TabIndex = 6
        lblTotal.Text = "Total Bill:"
        ' 
        ' lblTax
        ' 
        lblTax.AutoSize = True
        lblTax.Location = New Point(49, 266)
        lblTax.Name = "lblTax"
        lblTax.Size = New Size(69, 15)
        lblTax.TabIndex = 7
        lblTax.Text = "Bill and Tax:"
        ' 
        ' lblFinal
        ' 
        lblFinal.AutoSize = True
        lblFinal.Location = New Point(49, 295)
        lblFinal.Name = "lblFinal"
        lblFinal.Size = New Size(94, 15)
        lblFinal.TabIndex = 8
        lblFinal.Text = "Bill, Tax, and Tip:"
        ' 
        ' txtTotal
        ' 
        txtTotal.Location = New Point(156, 229)
        txtTotal.Name = "txtTotal"
        txtTotal.Size = New Size(100, 23)
        txtTotal.TabIndex = 9
        ' 
        ' txtTax
        ' 
        txtTax.Location = New Point(156, 258)
        txtTax.Name = "txtTax"
        txtTax.Size = New Size(100, 23)
        txtTax.TabIndex = 10
        ' 
        ' txtFinal
        ' 
        txtFinal.Location = New Point(156, 287)
        txtFinal.Name = "txtFinal"
        txtFinal.Size = New Size(100, 23)
        txtFinal.TabIndex = 11
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(304, 364)
        Controls.Add(txtFinal)
        Controls.Add(txtTax)
        Controls.Add(txtTotal)
        Controls.Add(lblFinal)
        Controls.Add(lblTax)
        Controls.Add(lblTotal)
        Controls.Add(btnCalc)
        Controls.Add(txtDrink)
        Controls.Add(txtFood)
        Controls.Add(lblDrink)
        Controls.Add(lblFood)
        Controls.Add(lblHead)
        Name = "Form1"
        Text = "Bill Calculator"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblHead As Label
    Friend WithEvents lblFood As Label
    Friend WithEvents lblDrink As Label
    Friend WithEvents txtFood As TextBox
    Friend WithEvents txtDrink As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblFinal As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtTax As TextBox
    Friend WithEvents txtFinal As TextBox

End Class
