﻿Public Class Form1
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        txtTotal.Text = CDec(txtFood.Text) + CDec(txtDrink.Text)
        txtTax.Text = (txtTotal.Text * 0.062) + txtTotal.Text
        txtFinal.Text = (txtTotal.Text * 0.15) + txtTax.Text
    End Sub

    Private Sub lblHead_Click(sender As Object, e As EventArgs) Handles lblHead.Click

    End Sub
End Class
