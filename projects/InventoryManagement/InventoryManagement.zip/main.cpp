// inventory management program. stores strings in vector 'rucksack'.
// allows user to check, add to, or remove from inventory depending on input (OR exit program)

#include <iostream>
#include <vector>
#include <string>
using std::cin;
using std::cout;
using std::string;
using std::vector;

int main() {
	vector<string> rucksack;
	bool continue_access = true;
	int item_index_ct = 1; // used to output #s on inventory list
	int item_index = 0;
	int option_select = 0;
	string new_item = "";

	while (continue_access) {
		// output menu options to user
		cout << "\n[ Rucksack Opened ]\n\n"
			<< "1. Check inventory\n"
			<< "2. Add to inventory\n"
			<< "3. Remove from inventory\n"
			<< "4. Exit\n\n"
			<< "Select an option: ";
		cin >> option_select;
		cout << "\n----------------------------------------------------\n";

		switch (option_select) {
			case 1: // check inv
				cout << "\nYou are carrying " << rucksack.size() << " items\n";
				// outputs extra newline if rucksack size is over 0 (for prettier formating/output purposes):
				if (rucksack.size() > 0) {
					cout << "\n";
				}
				item_index_ct = 1; // resets counter to 1
				// loops through every item in rucksack:
				for (string item : rucksack) {
					cout << item_index_ct << ". " << item << "\n";
					item_index_ct++;
				}
				cout << "\n----------------------------------------------------\n";
				break;

			case 2: // add to inv
				cout << "\nEnter the name of the item you would like to add: ";
				cin.ignore();
				getline(cin, new_item);
				rucksack.push_back(new_item);
				cout << "\n" << new_item << " has been stored in your rucksack!\n"
					<< "\n----------------------------------------------------\n";
				break;

			case 3: // remove from inv
				// breaks out of case early if rucksack is empty:
				if (rucksack.size() == 0) {
					cout << "\nYour rucksack is already empty!\n"
						<< "\n----------------------------------------------------\n";
					break;
				}
				item_index_ct = 1; // resets counter to 1
				cout << "\nYou are carrying " << rucksack.size() << " items\n\n";
				for (string item : rucksack) {
					cout << item_index_ct << ". " << item << "\n";
					item_index_ct++;
				}
				cout << "\nEnter the # of the item you would like to remove: ";
				cin >> item_index;
				// refuses removal if index entered not in inv range:
				if ( item_index > rucksack.size() || item_index < 1 ) {
					cout << "\nItem not found.\n";
				} 
				else {
					cout << "\nThrowing away " << rucksack.at(item_index - 1) << "...\n";
					rucksack.erase(rucksack.begin() + (item_index -1));
				}
				cout << "\n----------------------------------------------------\n";
				break;

			case 4: // exit
				// sets loop control variable to the exit condition:
				continue_access = false;
				break;

			default:
				cout << "\nInvalid option! Try again ~\n";
				cout << "\n----------------------------------------------------\n";;
				break;
		}

	}
	cout << "\n[ Rucksack Closed ]\nBack to your adventure!\nPress enter to exit.\n";
	cin.get();cin.get();

	return 0;
}